package com.safeanchor;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.PlayerSkinDrawer;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.entity.player.PlayerEntity;

public class Hud {
    public static void render(DrawContext ctx, RenderTickCounter tc) {
        MinecraftClient mc = MinecraftClient.getInstance();
        Config c = Config.I;
        if (!c.enabled || mc.player == null || mc.world == null || mc.options.hudHidden) return;
        int W = ctx.getScaledWindowWidth(), H = ctx.getScaledWindowHeight();

        if (c.showTitle) Util.title(ctx, 4, 4, 1.6f);

        if (c.counterOn) {
            String s = "Người chơi: " + Esp.countPlayers(mc);
            int w = mc.textRenderer.getWidth(s);
            int x = (int) ((W - w - 4) * c.counterX / 100.0) + 2, y = (int) ((H - 12) * c.counterY / 100.0) + 2;
            ctx.fill(x - 2, y - 2, x + w + 2, y + 10, 0x90000000);
            ctx.drawText(mc.textRenderer, s, x, y, 0xFFFF69B4, true);
        }
        if (c.radarOn) radar(ctx, mc, c, W, H);
        if (c.healthTag) healthTags(ctx, mc, c, W, H, tc.getTickDelta(false));
        if (c.aimbot && c.aimCircle) {
            double vfov = Math.max(30, mc.options.getFov().getValue());
            double r = (H / 2.0) * Math.tan(Math.toRadians(Math.min(80, c.aimFov))) / Math.tan(Math.toRadians(vfov / 2.0));
            int cx = W / 2, cy = H / 2, col = 0xFF000000 | c.aimColor;
            for (int i = 0; i < 90; i++) {
                double a = i * Math.PI * 2 / 90;
                int x = cx + (int) Math.round(Math.cos(a) * r), y = cy + (int) Math.round(Math.sin(a) * r);
                ctx.fill(x, y, x + 2, y + 2, col);
            }
        }
    }

    static void healthTags(DrawContext ctx, MinecraftClient mc, Config c, int W, int H, float td) {
        var cam = mc.gameRenderer.getCamera();
        net.minecraft.util.math.Vec3d cp = cam.getPos();
        net.minecraft.util.math.Vec3d f = net.minecraft.util.math.Vec3d.fromPolar(cam.getPitch(), cam.getYaw());
        net.minecraft.util.math.Vec3d right = net.minecraft.util.math.Vec3d.fromPolar(0, cam.getYaw() + 90f);
        net.minecraft.util.math.Vec3d up = net.minecraft.util.math.Vec3d.fromPolar(cam.getPitch() - 90f, cam.getYaw());
        double tanV = Math.tan(Math.toRadians(Math.max(30, mc.options.getFov().getValue()) / 2.0));
        double aspect = (double) W / H;
        for (PlayerEntity o : mc.world.getPlayers()) {
            if (o == mc.player || o.isSpectator() || o.squaredDistanceTo(mc.player) > c.espRange * c.espRange) continue;
            net.minecraft.util.math.Vec3d v = o.getLerpedPos(td).add(0, o.getHeight() + 0.5, 0).subtract(cp);
            double z = v.dotProduct(f);
            if (z <= 0.1) continue;
            double sx = W / 2.0 * (1 + v.dotProduct(right) / z / (tanV * aspect));
            double sy = H / 2.0 * (1 - v.dotProduct(up) / z / tanV);
            float hp = o.getHealth() + o.getAbsorptionAmount();
            String s = String.format("%.1f ♥", hp);
            int col = hp > 14 ? 0xFF55FF55 : hp > 7 ? 0xFFFFFF55 : 0xFFFF5555;
            int w = mc.textRenderer.getWidth(s);
            ctx.fill((int) sx - w / 2 - 2, (int) sy - 2, (int) sx + w / 2 + 2, (int) sy + 10, 0x90000000);
            ctx.drawText(mc.textRenderer, s, (int) sx - w / 2, (int) sy, col, true);
        }
    }

    static void tiny(DrawContext ctx, MinecraftClient mc, String t, float x, float y, int col) {
        var m = ctx.getMatrices();
        m.push(); m.translate(x, y, 0); m.scale(0.5f, 0.5f, 1f);
        ctx.drawText(mc.textRenderer, t, 0, 0, col, true);
        m.pop();
    }

    /**
     * Radar: tự quét mọi người chơi / block đã tải (xuyên tường, không cần nhìn thấy), kể cả ở trên hoặc dưới bạn.
     * Block vẽ bằng icon 2D; ▲ đỏ = ở trên bạn, ▼ xanh = ở dưới bạn (kèm chênh cao khi là người chơi).
     */
    static void radar(DrawContext ctx, MinecraftClient mc, Config c, int W, int H) {
        int S = Math.max(40, c.radarSize);
        int x0 = (int) ((W - S) * c.radarX / 100.0), y0 = (int) ((H - S) * c.radarY / 100.0);
        int cx = x0 + S / 2, cy = y0 + S / 2;
        ctx.fill(x0, y0, x0 + S, y0 + S, 0x80000000);
        ctx.fill(x0, y0, x0 + S, y0 + 1, 0xFFFF69B4); ctx.fill(x0, y0 + S - 1, x0 + S, y0 + S, 0xFFFF69B4);
        ctx.fill(x0, y0, x0 + 1, y0 + S, 0xFFFF69B4); ctx.fill(x0 + S - 1, y0, x0 + S, y0 + S, 0xFFFF69B4);
        ctx.fill(cx, y0 + 1, cx + 1, y0 + S - 1, 0x40FFFFFF); ctx.fill(x0 + 1, cy, x0 + S - 1, cy + 1, 0x40FFFFFF);

        double yaw = Math.toRadians(mc.player.getYaw());
        double fx = -Math.sin(yaw), fz = Math.cos(yaw), rx = -Math.cos(yaw), rz = -Math.sin(yaw);
        double scale = (S / 2.0 - 5) / c.radarRange;
        double py0 = mc.player.getY();

        if (c.radarBlocks) {
            java.util.HashSet<Long> cells = new java.util.HashSet<>();
            int n = 0, icons = 0;
            for (BlockEsp.Hit h : BlockEsp.hits()) {
                double dx = h.pos().getX() + 0.5 - mc.player.getX(), dz = h.pos().getZ() + 0.5 - mc.player.getZ();
                double sx = (dx * rx + dz * rz) * scale, sy = -(dx * fx + dz * fz) * scale;
                if (Math.abs(sx) > S / 2.0 - 5 || Math.abs(sy) > S / 2.0 - 5) continue;
                int bx = cx + (int) Math.round(sx), by = cy + (int) Math.round(sy);
                long cell = ((long) Math.floorDiv(bx, 5) << 32) ^ (Math.floorDiv(by, 5) & 0xffffffffL);
                if (!cells.add(cell)) continue;                         // mỗi ô radar chỉ vẽ 1 block cho đỡ rối / đỡ lag
                double dy = h.pos().getY() + 0.5 - py0;
                net.minecraft.item.Item it = net.minecraft.item.Items.AIR;
                if (c.radarIcons && icons < 90) it = mc.world.getBlockState(h.pos()).getBlock().asItem();
                if (it != net.minecraft.item.Items.AIR) {
                    var m = ctx.getMatrices();
                    m.push(); m.translate(bx - 4, by - 4, 0); m.scale(0.5f, 0.5f, 1f);
                    ctx.drawItem(new net.minecraft.item.ItemStack(it), 0, 0);
                    m.pop();
                    icons++;
                } else {
                    ctx.fill(bx - 1, by - 1, bx + 2, by + 2, 0xFF000000 | h.color());
                }
                if (c.radarVert && Math.abs(dy) > 2.5) tiny(ctx, mc, dy > 0 ? "▲" : "▼", bx + 2, by - 5, dy > 0 ? 0xFFFF5555 : 0xFF55FFFF);
                if (++n > 400) break;
            }
        }
        if (c.radarPlayers) {
            for (PlayerEntity o : mc.world.getPlayers()) {
                if (o == mc.player || o.isSpectator()) continue;
                double dx = o.getX() - mc.player.getX(), dz = o.getZ() - mc.player.getZ();
                double sx = (dx * rx + dz * rz) * scale, sy = -(dx * fx + dz * fz) * scale;
                double lim = S / 2.0 - 5;
                sx = Math.max(-lim, Math.min(lim, sx)); sy = Math.max(-lim, Math.min(lim, sy));
                int px = cx + (int) Math.round(sx), py = cy + (int) Math.round(sy);
                if (o instanceof net.minecraft.client.network.AbstractClientPlayerEntity ap)
                    PlayerSkinDrawer.draw(ctx, ap.getSkinTextures(), px - 4, py - 4, 8);
                else ctx.fill(px - 3, py - 3, px + 3, py + 3, 0xFFFF69B4);
                double dy = o.getY() - py0;
                if (c.radarVert && Math.abs(dy) > 2.5) {
                    tiny(ctx, mc, (dy > 0 ? "▲" : "▼") + (int) Math.abs(Math.round(dy)), px + 5, py - 3, dy > 0 ? 0xFFFF5555 : 0xFF55FFFF);
                }
            }
        }
        ctx.fill(cx - 1, cy - 1, cx + 2, cy + 2, 0xFF00FF00);
    }
}
