package com.safeanchor;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ClickableWidget;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Supplier;

/** Trang cài đặt v2.9: Macro tự thiết kế, trượt mượt khi tp, âm bàn phím. */
public class Pages3 {
    static Config C() { return Config.I; }
    static MinecraftClient mc() { return MinecraftClient.getInstance(); }

    static void set(List<String> steps, Screen p) {
        C().macroSeq.clear();
        C().macroSeq.addAll(steps);
        Config.save();
        mc().setScreen(macro(p));
    }

    static Screen macro(Screen p) {
        List<Supplier<ClickableWidget>> m = new ArrayList<>();
        m.add(Pages.button("▶ Chạy macro ngay (nhìn vào 1 block)", () -> { mc().setScreen(null); MacroBuilder.start(mc()); }));
        m.add(Pages.slider("Độ trễ giữa các bước (tick)", 0, 10, true, () -> C().comboDelay, v -> C().comboDelay = (int) v));

        m.add(Pages.button("§7--- Các bước đang có (chạm vào để xóa) ---", () -> {}));
        List<String> cur = new ArrayList<>(C().macroSeq);
        if (cur.isEmpty()) m.add(Pages.button("(trống) hãy thêm bước bên dưới", () -> {}));
        for (int i = 0; i < cur.size(); i++) {
            final int at = i;
            m.add(Pages.button("❌ " + (i + 1) + ". " + MacroBuilder.label(cur.get(i)), () -> {
                if (at < C().macroSeq.size()) C().macroSeq.remove(at);
                Config.save();
                mc().setScreen(macro(p));
            }));
        }
        m.add(Pages.button("🗑 Xóa hết các bước", () -> set(new ArrayList<>(), p)));

        m.add(Pages.button("§7--- Mẫu có sẵn ---", () -> {}));
        m.add(Pages.button("Mẫu: Anchor + obsidian chắn + totem + nổ", () -> set(List.of("ANCHOR", "GLOW", "OBS_SHIELD", "TOTEM", "EXPLODE"), p)));
        m.add(Pages.button("Mẫu: Obsidian + Crystal + đập nổ", () -> set(List.of("OBS", "CRYSTAL", "WAIT:1", "HIT_CRYSTAL"), p)));
        m.add(Pages.button("Mẫu: Totem tay phụ + Obsidian sau lưng", () -> set(List.of("TOTEM_OFF", "OBS_BACK"), p)));

        m.add(Pages.button("§7--- Thêm bước (nối vào cuối) ---", () -> {}));
        for (int i = 0; i < MacroBuilder.IDS.length; i++) {
            final String id = MacroBuilder.IDS[i];
            m.add(Pages.button("➕ " + MacroBuilder.NAMES[i], () -> {
                C().macroSeq.add(id); Config.save(); mc().setScreen(macro(p));
            }));
        }
        m.add(Pages.slider("Số tick chờ (dùng cho nút bên dưới)", 1, 20, true, () -> C().macroWaitPick, v -> C().macroWaitPick = (int) v));
        m.add(Pages.button("➕ Chờ (số tick ở trên)", () -> {
            C().macroSeq.add("WAIT:" + C().macroWaitPick); Config.save(); mc().setScreen(macro(p));
        }));
        m.add(Pages.slider("Ô hotbar (dùng cho nút bên dưới)", 1, 9, true, () -> C().macroSlotPick, v -> C().macroSlotPick = (int) v));
        m.add(Pages.button("➕ Chọn ô hotbar (số ở trên)", () -> {
            C().macroSeq.add("SLOT:" + C().macroSlotPick); Config.save(); mc().setScreen(macro(p));
        }));
        return new MenuScreen("Macro tự thiết kế (phím K)", p, m);
    }

    static Screen glide(Screen p) {
        List<Supplier<ClickableWidget>> m = new ArrayList<>();
        m.add(Pages.toggle("Trượt mượt khi tp (pearl, chorus...)", () -> C().tpGlide, v -> C().tpGlide = v));
        m.add(Pages.slider("Thời gian trượt (ms)", 150, 1500, true, () -> C().tpMs, v -> C().tpMs = (int) v));
        m.add(Pages.slider("Chỉ trượt khi dịch xa hơn (block)", 2, 30, true, () -> C().tpMin, v -> C().tpMin = v));
        return new MenuScreen("Trượt mượt khi tp", p, m);
    }

    static Screen keys(Screen p) {
        List<Supplier<ClickableWidget>> m = new ArrayList<>();
        m.add(Pages.toggle("Âm bàn phím / chuột (kiểu Creamy Keys)", () -> C().keySound, v -> C().keySound = v));
        m.add(Pages.cycle("Kiểu tiếng", new String[]{"Thock (trầm)", "Click (hat)", "Click UI", "Bit"}, () -> C().keySoundType, v -> C().keySoundType = v));
        m.add(Pages.slider("Cao độ (%)", 50, 200, true, () -> C().keySoundPitch, v -> C().keySoundPitch = (int) v));
        m.add(Pages.toggle("Có tiếng cả khi nhả phím", () -> C().keySoundRelease, v -> C().keySoundRelease = v));
        m.add(Pages.toggle("Hiện Keystrokes (WASD + chuột + CPS)", () -> C().hudKeys, v -> C().hudKeys = v));
        return new MenuScreen("Âm bàn phím", p, m);
    }
}
