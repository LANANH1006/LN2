package com.safeanchor;

import net.minecraft.block.Block;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.Registries;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;

/**
 * Gõ tên (vd "log", "oak log") -> hiện toàn bộ item/block có chữ đó, kèm hình 2D. Vuốt / lăn chuột lên xuống để tìm,
 * chạm vào để chọn. list != null: bật/tắt id trong list (ESP block, tự đào...). list == null: chọn 1 món rồi đóng (single).
 */
public class PickScreen extends Screen {
    final Screen parent;
    final boolean items;
    final List<String> list;
    final Consumer<String> single;
    final String head;
    TextFieldWidget field;
    final List<Identifier> results = new ArrayList<>();
    double scroll, py;
    boolean pend, drag;
    static final int ROW = 24;

    public PickScreen(Screen parent, String head, boolean items, List<String> list, Consumer<String> single) {
        super(Text.literal(head));
        this.parent = parent; this.head = head; this.items = items; this.list = list; this.single = single;
    }

    int top() { return 56; }
    int bottom() { return height - 32; }

    static String key(Identifier i) { return i.getNamespace().equals("minecraft") ? i.getPath() : i.toString(); }

    @Override protected void init() {
        field = new TextFieldWidget(textRenderer, width / 2 - 110, 28, 220, 20, Text.literal("tìm"));
        field.setPlaceholder(Text.literal("gõ tên: log, oak log, diamond..."));
        field.setMaxLength(48);
        field.setChangedListener(s -> { scroll = 0; refresh(s); });
        addDrawableChild(field);
        setInitialFocus(field);
        addDrawableChild(ButtonWidget.builder(Text.literal("Xong"), b -> close()).dimensions(width / 2 - 60, height - 26, 120, 20).build());
        refresh(field.getText());
    }

    void consider(Identifier id, String name, List<Identifier> out, String[] words) {
        String path = id.getPath(), nm = name.toLowerCase();
        for (String w : words) { if (w.isEmpty()) continue; if (!path.contains(w) && !nm.contains(w)) return; }
        out.add(id);
    }

    void refresh(String q) {
        results.clear();
        String s = q.toLowerCase().trim();
        if (s.isEmpty()) {          // chưa gõ gì: hiện những món đã chọn
            if (list != null) for (String k : list) {
                Identifier i = Identifier.tryParse(k.contains(":") ? k : "minecraft:" + k);
                if (i != null) results.add(i);
            }
            return;
        }
        String[] words = s.split("\\s+");
        List<Identifier> out = new ArrayList<>();
        if (items) {
            for (Item it : Registries.ITEM) { if (it == Items.AIR) continue; consider(Registries.ITEM.getId(it), it.getName().getString(), out, words); }
        } else {
            for (Block b : Registries.BLOCK) { if (b.asItem() == Items.AIR) continue; consider(Registries.BLOCK.getId(b), b.getName().getString(), out, words); }
        }
        String w0 = words[0];
        out.sort((a, b) -> {
            int sa = a.getPath().startsWith(w0) ? 0 : 1, sb = b.getPath().startsWith(w0) ? 0 : 1;
            return sa != sb ? sa - sb : a.getPath().compareTo(b.getPath());
        });
        results.addAll(out.subList(0, Math.min(400, out.size())));
    }

    Item itemOf(Identifier id) { return items ? Registries.ITEM.get(id) : Registries.BLOCK.get(id).asItem(); }
    String nameOf(Identifier id) { return items ? Registries.ITEM.get(id).getName().getString() : Registries.BLOCK.get(id).getName().getString(); }

    @Override public void close() { Config.save(); MinecraftClient.getInstance().setScreen(parent); }

    @Override public void renderBackground(DrawContext ctx, int mx, int my, float d) { ctx.fill(0, 0, width, height, 0xE0101018); }

    @Override public void render(DrawContext ctx, int mx, int my, float d) {
        super.render(ctx, mx, my, d);
        ctx.drawCenteredTextWithShadow(textRenderer, Text.literal(head), width / 2, 10, 0xFFB388FF);
        ctx.drawCenteredTextWithShadow(textRenderer, Text.literal(results.isEmpty() && field.getText().isBlank() ? "Gõ tên để tìm • vuốt lên/xuống để cuộn • chạm để chọn" : results.size() + " kết quả"), width / 2, 48 - 1, 0xFF9090A0);
        ctx.enableScissor(0, top() + 8, width, bottom());
        for (int i = 0; i < results.size(); i++) {
            int y = (int) (top() + 8 + i * ROW - scroll);
            if (y + ROW < top() + 8 || y > bottom()) continue;
            Identifier id = results.get(i);
            boolean on = list != null && list.contains(key(id));
            int x = width / 2 - 130;
            boolean hov = mx >= x && mx <= x + 260 && my >= y && my < y + ROW - 2;
            ctx.fill(x, y, x + 260, y + ROW - 2, on ? 0x80306030 : hov ? 0x80403060 : 0x80202030);
            ctx.drawItem(new ItemStack(itemOf(id)), x + 4, y + 3);
            ctx.drawText(textRenderer, Text.literal(nameOf(id)), x + 28, y + 3, 0xFFFFFFFF, false);
            ctx.drawText(textRenderer, Text.literal(key(id)), x + 28, y + 13, 0xFF9090A0, false);
            if (on) ctx.drawText(textRenderer, Text.literal("✔ đã chọn"), x + 200, y + 8, 0xFF55FF55, false);
        }
        ctx.disableScissor();
    }

    void scrollBy(double dy) {
        double max = Math.max(0, results.size() * ROW + 8 - (bottom() - top()));
        scroll = Math.max(0, Math.min(max, scroll + dy));
    }

    @Override public boolean mouseClicked(double x, double y, int b) {
        if (y >= top() + 8 && y <= bottom()) { pend = true; drag = false; py = y; return true; }
        return super.mouseClicked(x, y, b);
    }
    @Override public boolean mouseDragged(double x, double y, int b, double dx, double dy) {
        if (pend) { if (Math.abs(y - py) > 4) drag = true; if (drag) scrollBy(-dy); return true; }
        return super.mouseDragged(x, y, b, dx, dy);
    }
    @Override public boolean mouseReleased(double x, double y, int b) {
        if (pend) {
            pend = false;
            if (!drag && x >= width / 2.0 - 130 && x <= width / 2.0 + 130) {
                int i = (int) ((y - top() - 8 + scroll) / ROW);
                if (i >= 0 && i < results.size()) choose(results.get(i));
            }
            drag = false;
            return true;
        }
        return super.mouseReleased(x, y, b);
    }
    @Override public boolean mouseScrolled(double x, double y, double h, double v) { scrollBy(-v * 20); return true; }

    void choose(Identifier id) {
        String k = key(id);
        if (list != null) {
            if (!list.remove(k)) list.add(k);
            Config.save();
        } else if (single != null) {
            single.accept(k);
            Config.save();
            close();
        }
    }
}
